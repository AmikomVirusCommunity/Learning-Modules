
$(document).ready(function () {
                $('#datetimepicker2').datepicker({
                    format: "dd-mm-yyyy",
                    autoclose:true
                });
            });