<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*-----------------------------------
	*---- Authentication Controller -------
	*-- coded by: Teras Code Digital Team ---
	*-----------------------------------*/

class Dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('app/dashboard');
	}

	public function index()
	{
		$sess = $this->session->userdata('logeddin');
		$id   = $sess['id'];

		$data_usr = $this->dashboard->user("where id_usr='$id'")->result_array();

		$data = array(
			'nama' => $data_usr[0]['nama'],
			'kelas' => $data_usr[0]['kelas'],
			'prodi' => $data_usr[0]['jurusan'],
		);

		$this->load->view('app/dashboard',$data);
	}
}
