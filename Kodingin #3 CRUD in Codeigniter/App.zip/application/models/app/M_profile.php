<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*-----------------------------------
	*---- Profile Models -------
	*-- coded by: HostingmU.Net Team ----
	*-----------------------------------*/

class M_profile extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function get_data($where ='')
	{
        return $this->db->query("select * from user_data $where;");
	}

	public function update($table, $where, $data){
		return $this->db->update($table, $where, $data);
	}

}
?>
