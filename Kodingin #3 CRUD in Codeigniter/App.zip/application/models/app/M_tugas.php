<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*-----------------------------------
	*---- Tugas Models -------
	*-- coded by: HostingmU.Net Team ----
	*-----------------------------------*/

class M_tugas extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function get_data($where =''){
        return $this->db->query("select * from tb_tugas $where;");
    }
    
    public function get_mhs($where =''){
        return $this->db->query("select * from user_data $where;");
	}

	public function update($table, $where, $data){
		return $this->db->update($table, $where, $data);
	}

}
?>
