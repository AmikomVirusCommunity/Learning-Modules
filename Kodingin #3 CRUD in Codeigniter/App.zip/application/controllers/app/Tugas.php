<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*-----------------------------------
	*---- Tugas Controller -------
	*-- coded by: Teras Code Digital Team ---
	*-----------------------------------*/

class Tugas extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('app/m_tugas');

		if ($this->session->userdata('logeddin') == NULL) {
			redirect('app/login');
		}
	}

	public function index()
	{	/* Get Session */
		$sess = $this->session->userdata('logeddin');
		$id   = $sess['id']; //Get ID from session
        
        /* Get Data Mahasiswa */
        $data_user = $this->m_tugas->get_mhs("where id_usr='$id'")->result_array();
        $kelas     = $data_user[0]['kelas']; /* Ambil data kelas dari mahasiswa yang login*/

		/* Get Data Tugas */
		$data_tugas = $this->m_tugas->get_data("where kelas='$kelas' AND status = 1")->result_array();

		
		/* Insert data to array */
		$data = array(
            'nama_usr' => $data_user[0]['nama'],
			'data_tugas' => $data_tugas,

		);
		
		/* Load Template */
		$theme_data['main_content'] = $this->load->view(DATA_TUGAS, $data, true);
		$this->load->view(MASTER, $theme_data);
	}

	public function update_data(){
		/* Get Session */
		$sess = $this->session->userdata('logeddin');
		$id   = $sess['id']; //Get ID from session

		if ($_POST){
			/* Ambil value data input dari view profile.php */
			$nama_usr 		= $this->input->post('nama_usr');
			$kelas 			= $this->input->post('kelas');
			$prodi 			= $this->input->post('prodi');
			$alamat 		= $this->input->post('alamat');
			$telp 			= $this->input->post('telp');
			$photo 			= $this->input->post('file');

			/* Simpan data dari variabel diatas ke dalam array
			   'nama'	=> $nama_usr,
			   |			|
			   nama (adalah kolom sesuai table)
			   $nama_usr (adalah variable get value diatas)
			*/

			$data = array(
				'nama'	=> $nama_usr,
				'kelas' => $kelas,
				'jurusan' => $prodi,
				'alamat' => $alamat,
				'telp' => $telp,
			);

			/* Query update data ke tabel user_data dengan value array diatas*/
			$this->m_profile->update('user_data', $data, array('id_usr' => $id));
			$this->session->set_flashdata('messages', '<script>alert("Data Disimpan")</script>');
			redirect('app/profile');
		}
	}
}
