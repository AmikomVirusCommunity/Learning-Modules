<?php echo $this->session->flashdata('messages');?>
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="tip-bottom">Form elements</a> <a href="#" class="current">Common elements</a> </div>
  <h1><?php echo $nama_usr?></h1>
</div>
<div class="container-fluid">
  <hr>
  <div class="row-fluid">
    <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Personal-info</h5>
        </div>
        <div class="widget-content nopadding">
          <center><img style="border-radius: 50%; max-width:50%; margin:40px;" src="<?php echo base_url('files/photo/').$photo?>" ></center>
          <?php echo form_open(base_url('app/profile/update'), array('class' => 'form-horizontal', 'role' =>'form'))?>
            <div class="control-group">
              <label class="control-label">Nama Lengkap :</label>
              <div class="controls">
                <input type="text" name="nama_usr" class="span11" placeholder="Nama Lengkap" value="<?php echo $nama_usr?>" />
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Kelas :</label>
              <div class="controls">
                <input type="text" name="kelas" class="span11" placeholder="Kelas"  value="<?php echo $kelas?>"/>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Jurusan :</label>
              <div class="controls">
                <input type="text"  name="prodi" class="span11" placeholder="Jurusan" value="<?php echo $prodi?>" />
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Alamat</label>
              <div class="controls">
                <input type="text" name="alamat" class="span11" placeholder="Alamat" value="<?php echo $alamat?>"/>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Telepon</label>
              <div class="controls">
                <input type="text" name="telp" class="span11" value="<?php echo $telp?>" />
                <span class="help-block">Masukan Nomor Telepon aktif</span> </div>
            </div>
            <div class="control-group">
              <label class="control-label">Foto</label>
              <div class="controls">
                <input type="file" name="file">
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-success">Simpan</button>
            </div>
          <?php echo form_close()?>
        </div>
      </div>
    </div>
  </div>
</div>