<div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Tables</a> </div>
    <h1>Data Tugas</h1>
  </div>
  <div class="container-fluid">
    <hr>
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-th"></i> </span>
            <h5>Daftar Tugas</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>Nama Tugas</th>
                  <th>Mata Kuliah</th>
                  <th>Dosen</th>
                  <th>Batas Akhir</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
            <?php foreach ($data_tugas as $d){ ?>
                <tr class="odd gradeX">
                  <td><?php echo $d['nama_tugas']?></td>
                  <td><?php echo $d['matkul']?></td>
                  <td><?php echo $d['dosen']?></td>
                  <td class="center"><?php echo $d['akhir']?></td>
                  <td class="center">
                    <button class="btn btn-success btn-mini">Lihat</button>
                  </td>
                </tr>
            <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
        
      </div>
    </div>
  </div>