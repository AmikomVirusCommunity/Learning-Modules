<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="<?php if($this->uri->segment(2)=="dashboard"){ echo 'active';} ?>"><a href="<?php echo base_url('app/dashboard') ?>"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    <li class="<?php if($this->uri->segment(2)=="profile"){ echo 'active';} ?>"> <a href="<?php echo base_url('app/profile') ?>"><i class="icon icon-signal"></i> <span>Profile</span></a> </li>
    <li class="<?php if($this->uri->segment(2)=="tugas"){ echo 'active';} ?>"> <a href="<?php echo base_url('app/tugas') ?>"><i class="icon icon-inbox"></i> <span>Data Tugas</span></a> </li>
  </ul>
</div>