
<!-- Start CDN Header -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/admin/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?php echo base_url()?>assets/admin/css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="<?php echo base_url()?>assets/admin/css/fullcalendar.css" />
<link rel="stylesheet" href="<?php echo base_url()?>assets/admin/css/matrix-style.css" />
<link rel="stylesheet" href="<?php echo base_url()?>assets/admin/css/matrix-media.css" />
<link href="<?php echo base_url()?>assets/admin/font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo base_url()?>assets/admin/css/jquery.gritter.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

<!-- Ini JS -->
<script src="<?php echo base_url()?>assets/admin/js/jquery.min.js"></script> 
<script src="<?php echo base_url()?>assets/admin/js/jquery.ui.custom.js"></script> 
<script src="<?php echo base_url()?>assets/admin/js/bootstrap.min.js"></script> 

<!-- End CDN Header -->
