<div class="row-fluid">
<div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Personal-info</h5>
        </div>
        <div class="widget-content nopadding">
          <form action="#" method="get" class="form-horizontal">
              <img src="<?php echo base_url('files/photo/').$photo?>" style="max-width:200px;">
            <div class="control-group">
              <label class="control-label">Nama Lengkap</label>
              <div class="controls">
                <input class="span11" placeholder="First name" value="<?php echo $nama_usr;?>" type="text">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Kelas :</label>
              <div class="controls">
                <input class="span11" placeholder="Last name" value="<?php echo $kelas;?>" type="text">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Jurusan :</label>
              <div class="controls">
                <input class="span11" placeholder="Enter Password" value="<?php echo $prodi;?>" type="text" >
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Telpon :</label>
              <div class="controls">
                <input class="span11" placeholder="Company name" value="<?php echo $telp;?>" type="text">
              </div>
            </div
            <div class="control-group">
              <label class="control-label">Alamat :</label>
              <div class="controls">
                <textarea class="span11"> <?php echo $alamat;?> </textarea>
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-success">Simpan</button>
            </div>
          </form>
        </div>
      </div>
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Form Elements</h5>
        </div>
        <div class="widget-content nopadding">
          <form action="#" method="get" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">Select input</label>
              <div class="controls">
                <div class="select2-container" id="s2id_autogen1">    <a href="#" onclick="return false;" class="select2-choice">   <span>First option</span><abbr class="select2-search-choice-close" style="display:none;"></abbr>   <div><b></b></div></a>    <div class="select2-drop select2-offscreen">   <div class="select2-search">       <input autocomplete="off" class="select2-input" tabindex="0" type="text">   </div>   <ul class="select2-results">   </ul></div></div><select style="display: none;">
                  <option>First option</option>
                  <option>Second option</option>
                  <option>Third option</option>
                  <option>Fourth option</option>
                  <option>Fifth option</option>
                  <option>Sixth option</option>
                  <option>Seventh option</option>
                  <option>Eighth option</option>
                </select>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Multiple Select input</label>
              <div class="controls">
                <div class="select2-container select2-container-multi" id="s2id_autogen2">    <ul class="select2-choices">  <li class="select2-search-choice">    <div>Second option</div>    <a href="#" onclick="return false;" class="select2-search-choice-close" tabindex="-1"></a></li><li class="select2-search-field">    <input autocomplete="off" class="select2-input" tabindex="0" style="width: 10px;" type="text">  </li></ul><div class="select2-drop select2-drop-multi" style="display:none;">   <ul class="select2-results">   </ul></div></div><select multiple="" style="display: none;">
                  <option>First option</option>
                  <option selected="">Second option</option>
                  <option>Third option</option>
                  <option>Fourth option</option>
                  <option>Fifth option</option>
                  <option>Sixth option</option>
                  <option>Seventh option</option>
                  <option>Eighth option</option>
                </select>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Radio inputs</label>
              <div class="controls">
                <label>
                  <div class="radio" id="uniform-undefined"><span><input name="radios" style="opacity: 0;" type="radio"></span></div>
                  First One</label>
                <label>
                  <div class="radio" id="uniform-undefined"><span><input name="radios" style="opacity: 0;" type="radio"></span></div>
                  Second One</label>
                <label>
                  <div class="radio" id="uniform-undefined"><span><input name="radios" style="opacity: 0;" type="radio"></span></div>
                  Third One</label>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Checkboxes</label>
              <div class="controls">
                <label>
                  <div class="checker" id="uniform-undefined"><span><input name="radios" style="opacity: 0;" type="checkbox"></span></div>
                  First One</label>
                <label>
                  <div class="checker" id="uniform-undefined"><span><input name="radios" style="opacity: 0;" type="checkbox"></span></div>
                  Second One</label>
                <label>
                  <div class="checker" id="uniform-undefined"><span><input name="radios" style="opacity: 0;" type="checkbox"></span></div>
                  Third One</label>
              </div>
            </div>
            <div class="control-group">
              <label for="checkboxes" class="control-label">Data Toggle checkbox</label>
              <div class="controls">
                <div data-toggle="buttons-checkbox" class="btn-group">
                  <button class="btn btn-primary" type="button">Left</button>
                  <button class="btn btn-primary" type="button">Middle</button>
                  <button class="btn btn-primary" type="button">Right</button>
                </div>
              </div>
            </div>
            <div class="control-group">
              <label for="checkboxes" class="control-label">Data Radio button</label>
              <div class="controls">
                <div data-toggle="buttons-radio" class="btn-group">
                  <button class="btn btn-primary" type="button">Left</button>
                  <button class="btn btn-primary" type="button">Middle</button>
                  <button class="btn btn-primary" type="button">Right</button>
                </div>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">File upload input</label>
              <div class="controls">
                <div class="uploader" id="uniform-undefined"><input size="19" style="opacity: 0;" type="file"><span class="filename" style="-moz-user-select: none;">No file selected</span><span class="action" style="-moz-user-select: none;">Choose File</span></div>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Disabled Input</label>
              <div class="controls">
                <input placeholder="You can't type anything…" disabled="" class="span11" type="text">
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-success">Save</button>
            </div>
          </form>
        </div>
      </div>
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Form Elements</h5>
        </div>
        <div class="widget-content nopadding">
          <form class="form-horizontal">
            <div class="control-group">
              <label class="control-label">Color picker (hex)</label>
              <div class="controls">
                <input data-color="#ffffff" value="#ffffff" class="colorpicker input-big span11" type="text">
                <span class="help-block">Color picker with Formate of  (hex)</span> </div>
            </div>
            <div class="control-group">
              <label class="control-label">Color picker (rgba)</label>
              <div class="controls">
                <input data-color="rgba(344,232,53,0.5)" value="rgba(344,232,53,0.5)" data-color-format="rgba" class="colorpicker span11" type="text">
                <span class="help-block">Color picker with Formate of  (rgba)</span> </div>
            </div>
            <div class="control-group">
              <label class="control-label">Date picker (dd-mm)</label>
              <div class="controls">
                <input data-date="01-02-2013" data-date-format="dd-mm-yyyy" value="01-02-2013" class="datepicker span11" type="text">
                <span class="help-block">Date with Formate of  (dd-mm-yy)</span> </div>
            </div>
            <div class="control-group">
              <label class="control-label">Date Picker (mm-dd)</label>
              <div class="controls">
                <div data-date="12-02-2012" class="input-append date datepicker">
                  <input value="12-02-2012" data-date-format="mm-dd-yyyy" class="span11" type="text">
                  <span class="add-on"><i class="icon-th"></i></span> </div>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Color Picker (rgb)</label>
              <div class="controls">
                <div data-color-format="rgb" data-color="rgb(155, 142, 180)" class="input-append color colorpicker colorpicker-rgb">
                  <input value="rgb(155, 142, 180)" class="span11" type="text">
                  <span class="add-on"><i style="background-color: rgb(155, 142, 180)"></i></span> </div>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Color Picker (hex)</label>
              <div class="controls">
                <div data-color-format="hex" data-color="#000000" class="input-append color colorpicker">
                  <input value="#000000" class="span11" type="text">
                  <span class="add-on"><i style="background-color: #000000"></i></span> </div>
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-success">Save</button>
              <button type="submit" class="btn btn-primary">Reset</button>
              <button type="submit" class="btn btn-info">Edit</button>
              <button type="submit" class="btn btn-danger">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
</div>