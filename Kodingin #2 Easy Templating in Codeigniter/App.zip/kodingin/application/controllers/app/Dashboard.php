<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*-----------------------------------
	*---- Dashboard Controller -------
	*-- coded by: Teras Code Digital Team ---
	*-----------------------------------*/

class Dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('app/m_dashboard');

		if ($this->session->userdata('logeddin') == NULL) {
			redirect('app/login');
		}
	}
	
	/**Kodingin: Nanda Reynaldi */
	public function index()
	{	/* Get Session */
		$sess = $this->session->userdata('logeddin'); //Menyimpan data session pada $sess
		$id   = $sess['id']; //Get ID dari session
		
		/* Get User Data by session */
		$data_usr = $this->m_dashboard->user("where id_usr='$id'")->result_array();
		//Kode diatas adalah query mengambil user data berdasarkan (where) user yang login.
		
		/* Insert data to array */
		$data = array(
			'nama_usr' => $data_usr[0]['nama'],
			'kelas' => $data_usr[0]['kelas'],
			'prodi' => $data_usr[0]['jurusan'],
		);
		
		/* Load Template */
		$theme_data['main_content'] = $this->load->view(DASHBOARD_ADM, $data, true);
		$this->load->view(MASTER, $theme_data);
	}
}
