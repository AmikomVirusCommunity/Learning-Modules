<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*-----------------------------------
	*---- Profile Controller -------
	*-- coded by: Teras Code Digital Team ---
	*-----------------------------------*/

class Profile extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('app/m_profile');

		if ($this->session->userdata('logeddin') == NULL) {
			redirect('app/login');
		}
	}

	public function index()
	{	/* Get Session */
		$sess = $this->session->userdata('logeddin');
		$id   = $sess['id']; //Get ID from session
		
		/* Get User Data by session */
		$data_usr = $this->m_profile->get_data("where id_usr='$id'")->result_array();

		
		/* Insert data to array */
		$data = array(
			'nama_usr' => $data_usr[0]['nama'],
			'kelas' => $data_usr[0]['kelas'],
            'prodi' => $data_usr[0]['jurusan'],
            'alamat' => $data_usr[0]['alamat'],
			'telp' => $data_usr[0]['telp'],
			'photo' => $data_usr[0]['photo'],

		);
		
		/* Load Template */
		$theme_data['main_content'] = $this->load->view(PROFILE_ADM, $data, true);
		$this->load->view(MASTER, $theme_data);
	}
}
